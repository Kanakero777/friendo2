class Top < ApplicationRecord
end
