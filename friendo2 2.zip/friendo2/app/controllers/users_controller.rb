class UsersController < ApplicationController
  def show
  end

  def search
  end

  def detail
    @detail = User.find(params[:id])
  end
end
