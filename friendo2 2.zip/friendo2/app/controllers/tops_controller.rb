class TopsController < ApplicationController
  def index
  end
end
